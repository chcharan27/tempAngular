import { Component } from '@angular/core';

@Component({
  selector: 'app-wellbeing',
  standalone: true,
  imports: [],
  templateUrl: './wellbeing.component.html',
  styleUrl: './wellbeing.component.css'
})
export class WellbeingComponent {

}
